﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person("Peter", 20);
            Person person2 = new Person("George", 19);
            Person person3 = new Person("Jose", 43);
        }
    }
}
