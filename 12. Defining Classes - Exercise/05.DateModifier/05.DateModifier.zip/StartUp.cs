﻿using System;

namespace _05.DateModifier
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateModifier.CalculateDaysSpan(Console.ReadLine(), Console.ReadLine()));
        }
    }
}
